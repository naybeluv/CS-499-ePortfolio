/*
 * File: DatabaseHelper.java
 * Author: Ja'net Lovelace
 * Course: CS 499 Computer Science Capstone
 * Purpose: Manage the SQLite database used by the
 * Business Operations Management System.
 */
package com.weighttrackerapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;
import java.util.ArrayList;
import android.content.ContentValues;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BusinessOperations.db";
    private static final int DATABASE_VERSION = 4;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //User table
        db.execSQL("CREATE TABLE users ( id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password TEXT)");


        //Inventory table
        db.execSQL("CREATE TABLE inventory (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "itemName TEXT UNIQUE NOT NULL, " +
                "quantityAllocated INTEGER NOT NULL DEFAULT 0, " +
                "quantityOnHand INTEGER NOT NULL DEFAULT 0, " +
                "replenishmentLevel INTEGER NOT NULL DEFAULT 0, " +
                "reorderRequested INTEGER NOT NULL DEFAULT 0)");

        //Work orders table
        db.execSQL("CREATE TABLE work_orders (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "title TEXT NOT NULL, " +
                "dateCreated TEXT NOT NULL, " +
                "priority TEXT NOT NULL, " +
                "status TEXT NOT NULL, " +
                "description TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS inventory (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "itemName TEXT UNIQUE NOT NULL, " +
                    "quantityAllocated INTEGER NOT NULL DEFAULT 0, " +
                    "quantityOnHand INTEGER NOT NULL DEFAULT 0, " +
                    "replenishmentLevel INTEGER NOT NULL DEFAULT 0)");
        }

        //Add reorder tracking to existing inventory tables
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE inventory ADD COLUMN reorderRequested INTEGER NOT NULL DEFAULT 0");
        }

        //Add work orders table for database version 4
        if (oldVersion < 4) {
            db.execSQL("CREATE TABLE IF NOT EXISTS work_orders (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "title TEXT NOT NULL, " +
                    "dateCreated TEXT NOT NULL, " +
                    "priority TEXT NOT NULL, " +
                    "status TEXT NOT NULL, " +
                    "description TEXT NOT NULL)");
        }


    }

    //Insert new inventory item
    public boolean insertInventoryItem(String itemName, int quantityAllocated,
                                       int quantityOnHand, int replenishmentLevel) {

        SQLiteDatabase db = this.getWritableDatabase();

        try {
            db.execSQL("INSERT INTO inventory " +
                            "(itemName, quantityAllocated, quantityOnHand, replenishmentLevel) " +
                            "VALUES (?, ?, ?, ?)",
                    new Object[]{itemName, quantityAllocated, quantityOnHand, replenishmentLevel});

            return true;

        } catch (android.database.sqlite.SQLiteConstraintException e) {
            return false;
        }
    }

    //Retrieve all inventory item names for the dropdown
    public ArrayList<String> getInventoryItemNames() {
        ArrayList<String> itemNames = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        //Retrieve item names in alphabetical order
        Cursor cursor = db.rawQuery(
                "SELECT itemName FROM inventory ORDER BY itemName ASC",
                null
        );

        while (cursor.moveToNext()) {
            itemNames.add(cursor.getString(0));
        }

        cursor.close();
        return itemNames;
    }

    //Retrieve inventory quantities for a selected item
    public int[] getInventoryQuantities(String itemName) {
        SQLiteDatabase db = this.getReadableDatabase();

        int[] quantities = new int[3];

        //Retrieve the allocated, on hand and replenishment quantities
        Cursor cursor = db.rawQuery(
                "SELECT quantityAllocated, quantityOnHand, replenishmentLevel " +
                        "FROM Inventory WHERE itemName = ?",
                new String[]{itemName}
        );

        if (cursor.moveToFirst()) {
            quantities[0] = cursor.getInt(0);
            quantities[1] = cursor.getInt(1);
            quantities[2] = cursor.getInt(2);
        }

        cursor.close();
        return quantities;
    }

    //Add selected inventory item to the reorder list
    public boolean addToReorderList(String itemName) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("reorderRequested", 1);

        int rowsUpdated = db.update(
                "inventory",
                values,
                "itemName = ?",
                new String[]{itemName}
        );

        return rowsUpdated > 0;
    }

    //Insert a new work order
    public boolean insertWorkOrder(String title, String dateCreated,
                                   String priority, String status,
                                   String description) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("dateCreated", dateCreated);
        values.put("priority", priority);
        values.put("status", status);
        values.put("description", description);

        long result = db.insert("work_orders", null, values);

        return result != -1;
    }

    //Retrieve active work orders from the database
    public ArrayList<String> getActiveWorkOrders() {

        ArrayList<String> workOrders = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT title, dateCreated, priority, status " +
                        "FROM work_orders WHERE status != ?",
                new String[]{"Completed"}
        );

        while (cursor.moveToNext()) {

            String title = cursor.getString(0);
            String date = cursor.getString(1);
            String priority = cursor.getString(2);
            String status = cursor.getString(3);

            String workOrder =
                    title +
                            "\nDate Created: " + date +
                            "\nPriority: " + priority +
                            "\nStatus: " + status;

            workOrders.add(workOrder);
        }

        cursor.close();

        return workOrders;
    }


    //Insert new user with a hashed password
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        String hashedPassword = hashPassword(password);

        try {
            db.execSQL(
                    "INSERT INTO users (username, password) VALUES (?, ?)",
                    new Object[]{username, hashedPassword}
            );
            return true;

        } catch (android.database.sqlite.SQLiteConstraintException e) {
            return false;
        }
    }


    //Check for existing user using the hashed password
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String hashedPassword = hashPassword(password);

        String query =
                "SELECT * FROM users WHERE username=? AND password=?";

        Cursor cursor = db.rawQuery(
                query,
                new String[]{username, hashedPassword}
        );

        boolean userExists = cursor.getCount() > 0;

        cursor.close();
        return userExists;
    }


    //Convert the password into a SHA-256 hash before storing or comparing it
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Unable to hash password.", e);
        }
    }

    //Count the total number of inventory items
    public int getInventoryCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM inventory",
                null
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();
        return count;
    }


    //Count inventory items that have reached the replenishment level
    public int getLowStockCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM inventory " +
                        "WHERE quantityOnHand <= replenishmentLevel",
                null
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();
        return count;
    }


    //Count work orders that are still open
    public int getOpenWorkOrderCount() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT COUNT(*) FROM work_orders " +
                        "WHERE status != ?",
                new String[]{"Completed"}
        );

        int count = 0;

        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }

        cursor.close();
        return count;
    }



}



