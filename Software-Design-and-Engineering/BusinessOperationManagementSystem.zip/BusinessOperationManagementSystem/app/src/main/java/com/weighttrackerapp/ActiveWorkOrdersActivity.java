package com.weighttrackerapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActiveWorkOrdersActivity extends AppCompatActivity {

    DatabaseHelper db;
    ListView workOrdersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_work_orders);

        //Connect to the database
        db = new DatabaseHelper(this);

        //Connect the Active Work Orders list
        workOrdersList = findViewById(R.id.listViewWorkOrders);

        //Retrieve active work orders from the database
        ArrayList<String> activeWorkOrders = db.getActiveWorkOrders();

        //Display active work orders on the screen
        ArrayAdapter<String> workOrderAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                activeWorkOrders
        );

        workOrdersList.setAdapter(workOrderAdapter);
    }
}