package com.weighttrackerapp;

import android.os.Bundle;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import java.util.ArrayList;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class InventoryActivity extends AppCompatActivity {
    AutoCompleteTextView itemName;
    EditText quantityAllocated;
    EditText quantityOnHand;
    EditText replenishmentLevel;
    Button reorderButton;
    Button addInventoryButton;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);

        itemName = findViewById(R.id.autoCompleteItemName);

        //Retrieve existing inventory item names from the database
        ArrayList<String> itemNames = db.getInventoryItemNames();

        //Create the dropdown list for existing inventory items
        ArrayAdapter<String> itemAdapter =  new ArrayAdapter<>(
                this,
                android.R.layout.simple_dropdown_item_1line,
                itemNames
        );

        //Connect the existing inventory items to the Item Name dropdown
        itemName.setAdapter(itemAdapter);

        //Show dropdown options when Item Name field is selected
        itemName.setThreshold(0);

        //Show existing inventory items when the Item Name field is clicked
        itemName.setOnClickListener(v -> itemName.showDropDown());


        quantityAllocated = findViewById(R.id.editTextQuantityAllocated);
        quantityOnHand = findViewById(R.id.editTextQuantityOnHand);
        replenishmentLevel = findViewById(R.id.editTextReplenishmentLevel);
        reorderButton = findViewById(R.id.buttonReorderItem);
        addInventoryButton = findViewById(R.id.buttonAddInventoryItem);

        //Fill the quantity fields when an existing inventory item is selected
        itemName.setOnItemClickListener((parent, view, position, id) -> {
                    String selectedItem = parent.getItemAtPosition(position).toString();

                    int[] quantities = db.getInventoryQuantities(selectedItem);

                    //Fill the quantity fields only when the selected item is found
                    if (quantities != null) {
                        quantityAllocated.setText(String.valueOf(quantities[0]));
                        quantityOnHand.setText(String.valueOf(quantities[1]));
                        replenishmentLevel.setText(String.valueOf(quantities[2]));
                    }
                });

        //Add the selected inventory item to the reorder list
        reorderButton.setOnClickListener(v -> {

            String selectedItem = itemName.getText().toString().trim();

            if (selectedItem.isEmpty()) {
                Toast.makeText(InventoryActivity.this,
                        "Select an inventory item first.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean reorderAdded = db.addToReorderList(selectedItem);

            if (reorderAdded) {
                Toast.makeText(InventoryActivity.this,
                        selectedItem + " added to the reorder list.",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(InventoryActivity.this,
                        "Unable to add item to reorder list.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        addInventoryButton.setOnClickListener(v -> {

            String name = itemName.getText().toString().trim();

            if (name.isEmpty()) {
                itemName.setError("Item name is required");
                return;
            }

            String allocatedText = quantityAllocated.getText().toString().trim();
            String onHandText = quantityOnHand.getText().toString().trim();
            String replenishmentText = replenishmentLevel.getText().toString().trim();

            if (allocatedText.isEmpty() || onHandText.isEmpty() || replenishmentText.isEmpty()) {
                Toast.makeText(InventoryActivity.this,
                        "All quantity fields are required.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int allocated;
            int onHand;
            int replenishment;

            //Validate that quantity values can be converted to numbers
            try {
                allocated = Integer.parseInt(allocatedText);
                onHand = Integer.parseInt(onHandText);
                replenishment = Integer.parseInt(replenishmentText);
            } catch (NumberFormatException e) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Enter valid quantity values.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            if (allocated < 0 || onHand < 0 || replenishment < 0) {
                Toast.makeText(InventoryActivity.this,
                        "Quantities cannot be negative.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean itemAdded = db.insertInventoryItem(
                    name,
                    allocated,
                    onHand,
                    replenishment
            );

            if (itemAdded) {
                Toast.makeText(InventoryActivity.this,
                        "Inventory item added successfully.",
                        Toast.LENGTH_SHORT).show();

                //Refresh the dropdown to include the newly added item
                itemNames.clear();
                itemNames.addAll(db.getInventoryItemNames());
                itemAdapter.notifyDataSetChanged();

                itemName.setText("");
                quantityAllocated.setText("");
                quantityOnHand.setText("");
                replenishmentLevel.setText("");

            } else {
                Toast.makeText(InventoryActivity.this,
                        "Item already exists.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}