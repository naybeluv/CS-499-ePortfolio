package com.weighttrackerapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ActiveWorkOrdersActivity extends AppCompatActivity {

    DatabaseHelper db;
    ListView workOrdersList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_work_orders);

        //Connect to the database
        db = new DatabaseHelper(this);

        //Connect the Active Work Orders list
        workOrdersList = findViewById(R.id.listViewWorkOrders);

        //Retrieve active work orders from the database
        ArrayList<WorkOrder> activeWorkOrders = db.getActiveWorkOrders();

        //Stores the formatted work orders that will be displayed on the screen
        ArrayList<String> workOrderDisplayList = new ArrayList<>();

        //Convert each prioritized WorkOrder object into display text
        for (WorkOrder workOrder : activeWorkOrders) {
            workOrderDisplayList.add(workOrder.getDisplayText());
        }

        //Display active work orders on the screen
        ArrayAdapter<String> workOrderAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                workOrderDisplayList
        );

        workOrdersList.setAdapter(workOrderAdapter);
    }
}