package com.weighttrackerapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.activity.EdgeToEdge;

public class HomeActivity extends AppCompatActivity {

    DatabaseHelper db;

    Button inventoryButton;
    Button workOrdersButton;

    //Dashboard summary counts
    TextView inventoryCount;
    TextView lowStockCount;
    TextView openOrdersCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        //Connect to the database
        db = new DatabaseHelper(this);

        //Connect dashboard buttons
        inventoryButton = findViewById(R.id.buttonInventory);
        workOrdersButton = findViewById(R.id.buttonWorkOrders);

        //Connect dashboard summary counts
        inventoryCount = findViewById(R.id.textViewInventoryCount);
        lowStockCount = findViewById(R.id.textViewLowStockCount);
        openOrdersCount = findViewById(R.id.textViewOpenOrdersCount);

        //Display current database totals on the dashboard
        inventoryCount.setText(String.valueOf(db.getInventoryCount()));
        lowStockCount.setText(String.valueOf(db.getLowStockCount()));
        openOrdersCount.setText(String.valueOf(db.getOpenWorkOrderCount()));

        //Open the Inventory Management screen
        inventoryButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    HomeActivity.this,
                    InventoryActivity.class
            );
            startActivity(intent);
        });

        //Open the Work Orders screen
        workOrdersButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    HomeActivity.this,
                    WorkOrdersActivity.class
            );
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        //Refresh dashboard totals when returning to the screen
        inventoryCount.setText(String.valueOf(db.getInventoryCount()));
        lowStockCount.setText(String.valueOf(db.getLowStockCount()));
        openOrdersCount.setText(String.valueOf(db.getOpenWorkOrderCount()));
    }
}
