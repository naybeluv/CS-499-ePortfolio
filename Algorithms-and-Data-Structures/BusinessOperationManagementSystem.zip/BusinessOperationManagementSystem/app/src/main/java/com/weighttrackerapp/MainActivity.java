/*
 * File: MainActivity.java
 * Author: Ja'net Lovelace
 * Course: CS 499 Computer Science Capstone
 * Purpose: Handles user login and authentication for the
 * Business Operations Management System
 */

package com.weighttrackerapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText username, password;
    Button loginButton;
    TextView createAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //connecting database
        db = new DatabaseHelper(this);

        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        loginButton = findViewById(R.id.buttonLogin);
        createAccount = findViewById(R.id.textViewCreateAccount);

        loginButton.setOnClickListener(v -> {

            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Validate login fields before accessing the database
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Username and  password are required.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if (db.checkUser(user, pass)){
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                //go to home screen
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);

            } else {
                // Do not automatically create an account after a failed login
                Toast.makeText(MainActivity.this,
                        "Invalid username or password.",
                        Toast.LENGTH_SHORT).show();

            }
        });

        // Create a new user account separately from the Login process
        createAccount.setOnClickListener(v -> {

            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Validate account information before accessing the database
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Username and password are required.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean accountCreated = db.insertUser(user, pass);

            if (accountCreated) {
                Toast.makeText(MainActivity.this,
                        "Account created. You can now log in.",
                        Toast.LENGTH_SHORT).show();

                username.setText("");
                password.setText("");
            } else {
                Toast.makeText(MainActivity.this,
                        "Username already exists.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}