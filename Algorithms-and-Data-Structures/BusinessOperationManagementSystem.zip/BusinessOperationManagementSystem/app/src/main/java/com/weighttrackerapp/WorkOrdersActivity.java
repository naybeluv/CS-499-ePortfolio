package com.weighttrackerapp;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WorkOrdersActivity extends AppCompatActivity {

    DatabaseHelper db;

    //Work order screen controls
    EditText workOrderTitle;
    TextView dateCreated;
    Spinner prioritySpinner;
    Spinner statusSpinner;
    EditText description;
    Button addWorkOrderButton;
    Button viewWorkOrdersButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_orders);

        //Connect to the database
        db = new DatabaseHelper(this);

        //Connect screen controls
        workOrderTitle = findViewById(R.id.editTextWorkOrderTitle);
        dateCreated = findViewById(R.id.textViewDateCreated);
        prioritySpinner = findViewById(R.id.spinnerPriority);
        statusSpinner = findViewById(R.id.spinnerStatus);
        description = findViewById(R.id.editTextDescription);
        addWorkOrderButton = findViewById(R.id.buttonAddWorkOrder);
        viewWorkOrdersButton = findViewById(R.id.buttonViewWorkOrders);

        //Display the current date when the work order is created
        String currentDate = new SimpleDateFormat(
                "MM/dd/yyyy",
                Locale.getDefault()
        ).format(new Date());

        dateCreated.setText("Date Created: " + currentDate);

        //Priority choices
        String[] priorities = {
                "Low",
                "Medium",
                "High"
        };

        ArrayAdapter<String> priorityAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                priorities
        );

        priorityAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        prioritySpinner.setAdapter(priorityAdapter);

        //Status choices
        String[] statuses = {
                "Open",
                "In Progress",
                "Completed"
        };

        ArrayAdapter<String> statusAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                statuses
        );

        statusAdapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
        );

        statusSpinner.setAdapter(statusAdapter);

        //Validate work order information before saving
        addWorkOrderButton.setOnClickListener(v -> {

            String title = workOrderTitle.getText().toString().trim();
            String workDescription = description.getText().toString().trim();

            if (title.isEmpty()) {
                workOrderTitle.setError("Work order title is required");
                return;
            }

            if (workDescription.isEmpty()) {
                description.setError("Description is required");
                return;
            }

            String priority = prioritySpinner.getSelectedItem().toString();
            String status = statusSpinner.getSelectedItem().toString();

            //Save the new work order to the database
            boolean workOrderAdded = db.insertWorkOrder(
                    title,
                    currentDate,
                    priority,
                    status,
                    workDescription
            );

            if (workOrderAdded) {
                Toast.makeText(
                        WorkOrdersActivity.this,
                        "Work order added successfully.",
                        Toast.LENGTH_SHORT
                ).show();

                //Clear the form for the next work order
                workOrderTitle.setText("");
                description.setText("");
                prioritySpinner.setSelection(0);
                statusSpinner.setSelection(0);

            } else {
                Toast.makeText(
                        WorkOrdersActivity.this,
                        "Unable to add work order.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        //Open the Active Work Orders screen
        viewWorkOrdersButton.setOnClickListener(v -> {
            Intent intent = new Intent(
                    WorkOrdersActivity.this,
                    ActiveWorkOrdersActivity.class
            );
            startActivity(intent);
        });
    }
}