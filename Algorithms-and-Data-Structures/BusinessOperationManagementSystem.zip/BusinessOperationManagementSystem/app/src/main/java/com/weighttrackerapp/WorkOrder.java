package com.weighttrackerapp;


//Stores the information needed to prioritize and display a work order
public class WorkOrder {

    //Basic work order information
    private String title;
    private String dateCreated;
    private String priority;
    private String status;
    private String description;

    //Values used by the work order prioritization algorithm
    private int daysOpen;
    private int priorityScore;

    //Create a work order object using information retrieved from the database
    public WorkOrder(String title, String dateCreated, String priority, String status, String description) {
        this.title = title;
        this.dateCreated = dateCreated;
        this.priority = priority;
        this.status = status;
        this.description = description;

        //These values will be calculated by the prioritization algorithm
        this.daysOpen = 0;
        this.priorityScore = 0;
    }

    //Returns the work order title
    public String getTitle() {
        return title;
    }

    //Returns the date the work order was created
    public String getDateCreated() {
        return dateCreated;
    }

    //Returns the work order priority level
    public String getPriority() {
        return priority;
    }

    //Returns the current work order status
    public String getStatus(){
        return status;
    }

    //Returns the number of days work order has been open
    public int getDaysOpen() {
        return daysOpen;
    }

    //Returns the calculated priority score
    public int getPriorityScore() {
        return priorityScore;
    }

    //Updates the number of days the work order has been open
    public void setDaysOpen(int daysOpen) {
        this.daysOpen = daysOpen;
    }

    //Updates the priority score calculated by the prioritization algorithm
    public void setPriorityScore(int priorityScore) {
        this.priorityScore = priorityScore;
    }

    //Formats the work order information for display on the Active Work Order screen
    public String getDisplayText() {
        return title +
                "\nDate Created: " + dateCreated +
                "\nPriority: " + priority +
                "\nStatus: " + status +
                "\nDescription: " + description +
                "\nDays Open: " + daysOpen +
                "\nPriority Score: " + priorityScore;
    }
}
