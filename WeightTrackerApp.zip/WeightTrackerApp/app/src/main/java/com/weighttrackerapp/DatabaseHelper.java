package com.weighttrackerapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightApp.db";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //User table
        db.execSQL("CREATE TABLE users ( id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");

        //Weight table
        db.execSQL("CREATE TABLE weights (id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, weight TEXT)");

        //Goal table
        db.execSQL("CREATE TABLE goal (id INTEGER PRIMARY KEY AUTOINCREMENT, goalWeight TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS goal");
        onCreate(db);
    }

    //Insert new user
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO users (username, password) VALUES (?, ?)", new Object[]{username, password});
        return true;
    }

    //Check for existing user
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM users WHERE username=? AND password=?";
        android.database.Cursor cursor = db.rawQuery(query, new String[]{username, password});

        if (cursor.getCount() > 0) {
            cursor.close();
            return true;
        } else {
            cursor.close();
            return false;
        }
    }

    public void insertWeight(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("INSERT INTO weights (date, weight) VALUES (?, ?)", new Object[]{date, weight});
    }

    public android.database.Cursor getAllWeights(){
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM weights", null);
    }

    public void deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM weights WHERE id=?", new Object[]{id});
    }

    public void insertGoal(String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM goal");//keeps only one goal
        db.execSQL("INSERT INTO goal (goalWeight) VALUES (?)", new Object[]{goalWeight});
    }

    public String getGoal() {
        SQLiteDatabase db = this.getReadableDatabase();
        android.database.Cursor cursor = db.rawQuery("SELECT goalWeight FROM goal LIMIT 1", null);

        if (cursor.moveToFirst()) {
            String goal = cursor.getString(0);
            cursor.close();
            return goal;
        }

        cursor.close();
        return null;
    }
}
