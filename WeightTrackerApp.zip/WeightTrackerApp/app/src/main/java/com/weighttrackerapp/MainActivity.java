package com.weighttrackerapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText username, password;
    Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        //connecting database
        db = new DatabaseHelper(this);

        username = findViewById(R.id.editTextText);
        password = findViewById(R.id.editTextText2);
        loginButton = findViewById(R.id.button);

        loginButton.setOnClickListener(v -> {

            String user = username.getText().toString();
            String pass = password.getText().toString();

            if (db.checkUser(user, pass)){
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();

                //go to home screen
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);

            } else {
                db.insertUser(user, pass);
                Toast.makeText(MainActivity.this, "Account Created", Toast.LENGTH_SHORT).show();

                //go to home screen
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);

            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}