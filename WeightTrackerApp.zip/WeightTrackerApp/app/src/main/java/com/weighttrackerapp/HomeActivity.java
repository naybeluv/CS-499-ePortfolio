package com.weighttrackerapp;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class HomeActivity  extends AppCompatActivity{

    DatabaseHelper db;
    EditText enterWeight;
    Button addButton;
    LinearLayout container;
    EditText goalWeight;
    Button setGoalButton;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_home);

        db = new DatabaseHelper(this);

        enterWeight = findViewById(R.id.textView15);
        addButton = findViewById(R.id.button2);
        container = findViewById(R.id.weightContainer);
        goalWeight = findViewById(R.id.editTextGoalWeight);
        setGoalButton = findViewById(R.id.buttonSetGoal);

        addButton.setOnClickListener(v-> {
            String weight = enterWeight.getText().toString();

            if (!weight.isEmpty()){
                String date = new java.text.SimpleDateFormat("MM/dd/yy").format(new java.util.Date());
                db.insertWeight(date, weight);

                String goal = db.getGoal();

                if (goal !=null) {
                    int enteredWeight = Integer.parseInt(weight);
                    int goalValue = Integer.parseInt(goal);

                    if (enteredWeight <= goalValue) {
                        Toast.makeText(HomeActivity.this, "Goal Reached!", Toast.LENGTH_LONG).show();
                        sendGoalReachedSMS();
                    }
                }
                container.removeAllViews();
                loadWeights();
                Toast.makeText(HomeActivity.this, "Weight Added", Toast.LENGTH_SHORT).show();
                enterWeight.setText("");
            } else {
                Toast.makeText(HomeActivity.this, "Enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        //set goal weight
        setGoalButton.setOnClickListener(v -> {
            String goal = goalWeight.getText().toString();
            if (!goal.isEmpty()) {
                db.insertGoal(goal);
                requestSMSPermission();
                Toast.makeText(HomeActivity.this, "Goal Set", Toast.LENGTH_SHORT).show();
                goalWeight.setText("");
            } else {
                Toast.makeText(HomeActivity.this, "Enter a goal weight", Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        loadWeights();
    }

    private void sendGoalReachedSMS() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
        == PackageManager.PERMISSION_GRANTED) {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("5551234567", null,
                    "Congratulations! You reached your goal weight.", null, null);

            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT). show();

        }
    }
    private void requestSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            !=PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }
    }

    private void loadWeights() {
        android.database.Cursor cursor = db.getAllWeights();

        if (cursor.getCount() == 0) {
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            String weight = cursor.getString(2);


            //Create a row layout
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            //fixing rows to align with header
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            //Date text
            TextView dateText = new TextView(this);
            dateText.setText(date);
            dateText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            dateText.setGravity(android.view.Gravity.CENTER);
            dateText.setTextSize(14);

            //Weight text
            TextView weightText = new TextView(this);
            weightText.setText(weight);
            weightText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            weightText.setGravity(android.view.Gravity.CENTER);
            weightText.setTextSize(14);

            //Delete text
            TextView deleteText = new TextView(this);
            deleteText.setText("[ X ]");
            deleteText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            deleteText.setGravity(android.view.Gravity.CENTER);
            deleteText.setTextSize(14);

            deleteText.setOnClickListener(v -> {
                db.deleteWeight(id);
                container.removeAllViews();
                loadWeights();
                Toast.makeText(HomeActivity.this, "Weight Deleted", Toast.LENGTH_SHORT).show();
            });

            //Add to row
            row.addView(dateText);
            row.addView(weightText);
            row.addView(deleteText);

            //add row to container
            container.addView(row);
        }
        cursor.close();

    }
}
